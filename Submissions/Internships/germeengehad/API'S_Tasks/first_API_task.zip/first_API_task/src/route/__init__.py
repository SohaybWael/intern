from fastapi import APIRouter
from route.api.user_router import userRouter
from route.api.task_router import taskRouter

userRouter = APIRouter()
taskRouter = APIRouter()

router.include_router(userRouter)
router.include_router(taskRouter)


