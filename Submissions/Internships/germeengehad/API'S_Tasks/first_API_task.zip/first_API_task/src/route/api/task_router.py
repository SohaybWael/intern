from fastapi import APIRouter, Body
from schema import  task ,Score
from main import app

taskRouter = APIRouter(
    prefix="/task", 
    tags=["task"]
    )


@taskRouter.post('/task')
def add_task(task: Task = Body(...)):
    return {'msg': 'Task added successfully', **task.dict()}

@taskRouter.get('/task/{id}')
def get_task(id: int, name: str):
    return f'Task: Id is {id} and name is {name} retrieved successfully'

@taskRouter.put('/task/{id}')
def update_task(id: int, name: str, score: Score = Body(...)):
    return {'msg': f'Task: ID is {id} and name is {name} updated successfully', **score.dict()}

@taskRouter.delete('/task/{id}')
def delete_task(id: int, name: str):
    return f'Task: ID is {id} and name is {name} deleted successfully'