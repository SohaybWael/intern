
from fastapi import APIRouter, Body
from schema import user , Product
from main import app

userRouter = APIRouter(
    prefix="/user", 
    tags=["user"]
    )


@userRouter.post('/user')
def add_user(user: user = Body(...)):
    return {'msg': 'User added successfully', **user.dict()}

@userRouter.get('/user/{id}')
def get_user(id: int, name: str):
    return f'User: Id is {id} and name is {name} retrieved successfully'

@userRouter.put('/user/{id}')
def update_user(id: int, name: str, product: Product = Body(...)):
    return {'msg': f'User: ID is {id} and name is {name} updated successfully', **product.dict()}

@userRouter.delete('/user/{id}')
def delete_user(id: int, name: str):
    return f'User: ID is {id} and name is {name} deleted successfully'