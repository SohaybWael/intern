import uvicorn
from fastapi import FastAPI
from route import router
from config import settings
from route.api.user_router import userRouter
from route.api.task_router import taskRouter


app = FastAPI(
    title=settings.APP_NAME,
    description="This is a template for FastAPI"
)

app.include_router(userRouter,taskRouter, prefix=settings.API_V1_STR)


if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        reload=settings.DEBUG_MODE,
        host=settings.DOMAIN,
        port=settings.BACKEND_PORT
    )

